#ifndef DATABASE_MANAGER_H
#define DATABASE_MANAGER_H

#include "sqlite/sqlite3.h"
#include <string>
#include <memory>
#include <stdexcept>

class DatabaseManager {
public:
    DatabaseManager(const std::string& db_path);
    ~DatabaseManager();
    
    void initializeDatabase();
    void enableForeignKeys();
    void createIndexes();
    
    sqlite3* getHandle() const { return db_; }
    
private:
    void createStudentsTable();
    void createGradesTable();
    
    sqlite3* db_;
    std::string db_path_;
};

#endif // DATABASE_MANAGER_H