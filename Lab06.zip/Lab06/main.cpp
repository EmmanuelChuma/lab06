#include "database_manager.h"
#include "student_repository.h"
#include "input_validator.h"
#include <iostream>
#include <chrono>
#include <vector>
#include <random>

void testBasicOperations() {
    std::cout << "=== Тестирование базовых операций ===" << std::endl;
    
    try {
        DatabaseManager db_manager("test.db");
        db_manager.initializeDatabase();
        
        StudentRepository repo(db_manager.getHandle());
        
        // Тест 1: Добавление студента
        std::cout << "1. Добавление студента..." << std::endl;
        bool added = repo.addStudent("Иван Иванов", "ivan@university.ru", "CS-101");
        std::cout << "   Результат: " << (added ? "Успешно" : "Ошибка") << std::endl;
        
        // Тест 2: Получение студента
        std::cout << "\n2. Получение студента по ID..." << std::endl;
        auto student = repo.getStudent(1);
        if (student) {
            std::cout << "   Найден: " << student->name 
                     << ", Email: " << student->email 
                     << ", Группа: " << student->group_name << std::endl;
        }
        
        // Тест 3: Добавление оценки
        std::cout << "\n3. Добавление оценки..." << std::endl;
        bool gradeAdded = repo.addGrade(1, "Математика", 85);
        std::cout << "   Результат: " << (gradeAdded ? "Успешно" : "Ошибка") << std::endl;
        
        // Тест 4: Получение всех студентов
        std::cout << "\n4. Получение всех студентов..." << std::endl;
        auto allStudents = repo.getAllStudents();
        std::cout << "   Количество студентов: " << allStudents.size() << std::endl;
        
        // Тест 5: Обновление студента
        std::cout << "\n5. Обновление студента..." << std::endl;
        bool updated = repo.updateStudent(1, "Иван Петров", 
                                         "ivan.petrov@university.ru", "CS-102");
        std::cout << "   Результат: " << (updated ? "Успешно" : "Ошибка") << std::endl;
        
    } catch (const std::exception& e) {
        std::cerr << "Ошибка: " << e.what() << std::endl;
    }
}

void testTransactions() {
    std::cout << "\n=== Тестирование транзакций ===" << std::endl;
    
    DatabaseManager db_manager("test.db");
    StudentRepository repo(db_manager.getHandle());
    
    std::vector<std::pair<std::string, int>> grades = {
        {"Математика", 90},
        {"Физика", 85},
        {"Программирование", 95}
    };
    
    std::cout << "Добавление студента с оценками в одной транзакции..." << std::endl;
    bool success = repo.addStudentWithGrades("Петр Петров", 
                                           "petr@university.ru", 
                                           "CS-101", grades);
    std::cout << "Результат: " << (success ? "Успешно" : "Ошибка") << std::endl;
}

void testComplexQueries() {
    std::cout << "\n=== Тестирование сложных запросов ===" << std::endl;
    
    DatabaseManager db_manager("test.db");
    StudentRepository repo(db_manager.getHandle());
    
    // Добавляем тестовые данные
    repo.addStudent("Алексей Сидоров", "alex@university.ru", "CS-101");
    repo.addStudent("Мария Иванова", "maria@university.ru", "CS-102");
    repo.addStudent("Сергей Петров", "sergey@university.ru", "CS-101");
    
    repo.addGrade(1, "Математика", 75);
    repo.addGrade(1, "Физика", 80);
    repo.addGrade(2, "Математика", 90);
    repo.addGrade(3, "Математика", 85);
    
    std::cout << "1. Студенты группы CS-101:" << std::endl;
    auto cs101_students = repo.getStudentsByGroup("CS-101");
    for (const auto& student : cs101_students) {
        std::cout << "   - " << student.name << std::endl;
    }
    
    std::cout << "\n2. Средняя оценка по математике: ";
    double avg = repo.getAverageGradeBySubject("Математика");
    std::cout << avg << std::endl;
    
    std::cout << "\n3. Лучшие студенты (топ-3):" << std::endl;
    auto topStudents = repo.getTopStudents(3);
    for (const auto& student : topStudents) {
        std::cout << "   - " << student.name 
                 << " (средний балл: " << student.getAverageGrade() << ")" << std::endl;
    }
}

void testBatchInsert() {
    std::cout << "\n=== Тестирование пакетной вставки ===" << std::endl;
    
    DatabaseManager db_manager("test.db");
    StudentRepository repo(db_manager.getHandle());
    
    std::vector<std::tuple<std::string, std::string, std::string>> students;
    
    // Генерируем 1000 студентов для теста производительности
    for (int i = 0; i < 1000; i++) {
        students.emplace_back(
            "Студент " + std::to_string(i),
            "student" + std::to_string(i) + "@university.ru",
            "GROUP-" + std::to_string(i % 10)
        );
    }
    
    auto start = std::chrono::high_resolution_clock::now();
    
    bool success = repo.batchInsertStudents(students);
    
    auto end = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end - start);
    
    std::cout << "Пакетная вставка 1000 студентов: " 
              << (success ? "Успешно" : "Ошибка") << std::endl;
    std::cout << "Время выполнения: " << duration.count() << " мс" << std::endl;
}

void testInputValidation() {
    std::cout << "\n=== Тестирование валидации ввода ===" << std::endl;
    
    try {
        std::cout << "1. Проверка валидного email: ";
        InputValidator::validateEmail("test@example.com");
        std::cout << "OK" << std::endl;
        
        std::cout << "2. Проверка невалидного email: ";
        InputValidator::validateEmail("invalid-email");
        std::cout << "ERROR (не должно быть достигнуто)" << std::endl;
    } catch (const std::exception& e) {
        std::cout << "Поймано исключение: " << e.what() << std::endl;
    }
    
    try {
        std::cout << "\n3. Проверка безопасного ввода: ";
        InputValidator::validateName("John Doe");
        std::cout << "OK" << std::endl;
        
        std::cout << "4. Проверка опасного ввода: ";
        InputValidator::validateName("John'; DROP TABLE students; --");
        std::cout << "ERROR (не должно быть достигнуто)" << std::endl;
    } catch (const std::exception& e) {
        std::cout << "Поймано исключение: " << e.what() << std::endl;
    }
}

void performanceTest() {
    std::cout << "\n=== Тест производительности ===" << std::endl;
    
    DatabaseManager db_manager("performance.db");
    db_manager.initializeDatabase();
    StudentRepository repo(db_manager.getHandle());
    
    // Очищаем таблицы
    sqlite3_exec(db_manager.getHandle(), "DELETE FROM students", nullptr, nullptr, nullptr);
    sqlite3_exec(db_manager.getHandle(), "DELETE FROM grades", nullptr, nullptr, nullptr);
    
    // Тест 1: Вставка по одному (без транзакции)
    std::cout << "1. Вставка 100 студентов по одному (без транзакции):" << std::endl;
    auto start = std::chrono::high_resolution_clock::now();
    
    for (int i = 0; i < 100; i++) {
        repo.addStudent("Тест " + std::to_string(i),
                       "test" + std::to_string(i) + "@test.com",
                       "TEST");
    }
    
    auto end = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end - start);
    std::cout << "   Время: " << duration.count() << " мс" << std::endl;
    
    // Очищаем и тестируем пакетную вставку
    sqlite3_exec(db_manager.getHandle(), "DELETE FROM students", nullptr, nullptr, nullptr);
    
    std::vector<std::tuple<std::string, std::string, std::string>> batch_students;
    for (int i = 0; i < 100; i++) {
        batch_students.emplace_back(
            "Тест " + std::to_string(i),
            "test" + std::to_string(i) + "@test.com",
            "TEST"
        );
    }
    
    std::cout << "\n2. Пакетная вставка 100 студентов:" << std::endl;
    start = std::chrono::high_resolution_clock::now();
    
    repo.batchInsertStudents(batch_students);
    
    end = std::chrono::high_resolution_clock::now();
    duration = std::chrono::duration_cast<std::chrono::milliseconds>(end - start);
    std::cout << "   Время: " << duration.count() << " мс" << std::endl;
}

int main() {
    std::cout << "ЛАБОРАТОРНАЯ РАБОТА: РАБОТА С БАЗАМИ ДАННЫХ В C++\n" << std::endl;
    
    try {
        // Удаляем старые тестовые файлы
        std::remove("test.db");
        std::remove("performance.db");
        
        testBasicOperations();
        testTransactions();
        testComplexQueries();
        testInputValidation();
        testBatchInsert();
        performanceTest();
        
        std::cout << "\n=== Все тесты завершены ===" << std::endl;
        
    } catch (const std::exception& e) {
        std::cerr << "Критическая ошибка: " << e.what() << std::endl;
        return 1;
    }
    
    return 0;
}