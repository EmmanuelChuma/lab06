#include "student_repository.h"
#include <iostream>
#include <sstream>
#include <iomanip>

StudentRepository::StudentRepository(sqlite3* db) : db_(db) {
    if (!db_) {
        throw std::invalid_argument("Database connection is null");
    }
}

bool StudentRepository::addStudent(const std::string& name, 
                                 const std::string& email, 
                                 const std::string& group) {
    
    // Валидация
    InputValidator::validateName(name);
    InputValidator::validateEmail(email);
    InputValidator::validateGroup(group);
    
    const char* sql = "INSERT INTO students (name, email, group_name) VALUES (?, ?, ?)";
    sqlite3_stmt* stmt;
    
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK) {
        std::cerr << "Failed to prepare statement: " << sqlite3_errmsg(db_) << std::endl;
        return false;
    }
    
    sqlite3_bind_text(stmt, 1, name.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 2, email.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 3, group.c_str(), -1, SQLITE_TRANSIENT);
    
    bool success = sqlite3_step(stmt) == SQLITE_DONE;
    
    sqlite3_finalize(stmt);
    return success;
}

std::optional<Student> StudentRepository::getStudent(int id) {
    const char* sql = "SELECT id, name, email, group_name, created_at FROM students WHERE id = ?";
    sqlite3_stmt* stmt;
    
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK) {
        return std::nullopt;
    }
    
    sqlite3_bind_int(stmt, 1, id);
    
    std::optional<Student> student;
    if (sqlite3_step(stmt) == SQLITE_ROW) {
        student = extractStudentFromStmt(stmt);
        // Получаем оценки студента
        if (student) {
            student->grades = getStudentGrades(id);
        }
    }
    
    sqlite3_finalize(stmt);
    return student;
}

bool StudentRepository::updateStudent(int id, const std::string& newName,
                                    const std::string& newEmail, 
                                    const std::string& newGroup) {
    
    InputValidator::validateName(newName);
    InputValidator::validateEmail(newEmail);
    InputValidator::validateGroup(newGroup);
    
    const char* sql = "UPDATE students SET name = ?, email = ?, group_name = ? WHERE id = ?";
    sqlite3_stmt* stmt;
    
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK) {
        return false;
    }
    
    sqlite3_bind_text(stmt, 1, newName.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 2, newEmail.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 3, newGroup.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_int(stmt, 4, id);
    
    bool success = sqlite3_step(stmt) == SQLITE_DONE;
    
    sqlite3_finalize(stmt);
    return success;
}

bool StudentRepository::deleteStudent(int id) {
    const char* sql = "DELETE FROM students WHERE id = ?";
    sqlite3_stmt* stmt;
    
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK) {
        return false;
    }
    
    sqlite3_bind_int(stmt, 1, id);
    
    bool success = sqlite3_step(stmt) == SQLITE_DONE;
    
    sqlite3_finalize(stmt);
    return success;
}

std::vector<Student> StudentRepository::getAllStudents() {
    const char* sql = "SELECT id, name, email, group_name, created_at FROM students ORDER BY name";
    sqlite3_stmt* stmt;
    std::vector<Student> students;
    
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK) {
        return students;
    }
    
    while (sqlite3_step(stmt) == SQLITE_ROW) {
        auto student = extractStudentFromStmt(stmt);
        student.grades = getStudentGrades(student.id);
        students.push_back(student);
    }
    
    sqlite3_finalize(stmt);
    return students;
}

bool StudentRepository::addGrade(int student_id, const std::string& subject, int grade) {
    InputValidator::validateGrade(grade);
    
    const char* sql = "INSERT INTO grades (student_id, subject, grade) VALUES (?, ?, ?)";
    sqlite3_stmt* stmt;
    
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK) {
        return false;
    }
    
    sqlite3_bind_int(stmt, 1, student_id);
    sqlite3_bind_text(stmt, 2, subject.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_int(stmt, 3, grade);
    
    bool success = sqlite3_step(stmt) == SQLITE_DONE;
    
    sqlite3_finalize(stmt);
    return success;
}

std::vector<Grade> StudentRepository::getStudentGrades(int student_id) {
    const char* sql = "SELECT id, student_id, subject, grade, exam_date FROM grades WHERE student_id = ?";
    sqlite3_stmt* stmt;
    std::vector<Grade> grades;
    
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK) {
        return grades;
    }
    
    sqlite3_bind_int(stmt, 1, student_id);
    
    while (sqlite3_step(stmt) == SQLITE_ROW) {
        grades.push_back(extractGradeFromStmt(stmt));
    }
    
    sqlite3_finalize(stmt);
    return grades;
}

bool StudentRepository::addStudentWithGrades(const std::string& name,
                                           const std::string& email,
                                           const std::string& group,
                                           const std::vector<std::pair<std::string, int>>& grades) {
    
    beginTransaction();
    
    try {
        // Добавляем студента
        const char* insertStudentSql = "INSERT INTO students (name, email, group_name) VALUES (?, ?, ?)";
        sqlite3_stmt* stmt;
        
        if (sqlite3_prepare_v2(db_, insertStudentSql, -1, &stmt, nullptr) != SQLITE_OK) {
            rollbackTransaction();
            return false;
        }
        
        sqlite3_bind_text(stmt, 1, name.c_str(), -1, SQLITE_TRANSIENT);
        sqlite3_bind_text(stmt, 2, email.c_str(), -1, SQLITE_TRANSIENT);
        sqlite3_bind_text(stmt, 3, group.c_str(), -1, SQLITE_TRANSIENT);
        
        if (sqlite3_step(stmt) != SQLITE_DONE) {
            sqlite3_finalize(stmt);
            rollbackTransaction();
            return false;
        }
        
        sqlite3_finalize(stmt);
        
        // Получаем ID добавленного студента
        int student_id = sqlite3_last_insert_rowid(db_);
        
        // Добавляем оценки
        const char* insertGradeSql = "INSERT INTO grades (student_id, subject, grade) VALUES (?, ?, ?)";
        
        for (const auto& [subject, grade] : grades) {
            if (sqlite3_prepare_v2(db_, insertGradeSql, -1, &stmt, nullptr) != SQLITE_OK) {
                rollbackTransaction();
                return false;
            }
            
            sqlite3_bind_int(stmt, 1, student_id);
            sqlite3_bind_text(stmt, 2, subject.c_str(), -1, SQLITE_TRANSIENT);
            sqlite3_bind_int(stmt, 3, grade);
            
            if (sqlite3_step(stmt) != SQLITE_DONE) {
                sqlite3_finalize(stmt);
                rollbackTransaction();
                return false;
            }
            
            sqlite3_finalize(stmt);
        }
        
        commitTransaction();
        return true;
        
    } catch (...) {
        rollbackTransaction();
        return false;
    }
}

std::vector<Student> StudentRepository::getStudentsByGroup(const std::string& group_name) {
    const char* sql = R"(
        SELECT s.id, s.name, s.email, s.group_name, s.created_at
        FROM students s
        WHERE s.group_name = ?
        ORDER BY s.name
    )";
    
    sqlite3_stmt* stmt;
    std::vector<Student> students;
    
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK) {
        return students;
    }
    
    sqlite3_bind_text(stmt, 1, group_name.c_str(), -1, SQLITE_TRANSIENT);
    
    while (sqlite3_step(stmt) == SQLITE_ROW) {
        auto student = extractStudentFromStmt(stmt);
        student.grades = getStudentGrades(student.id);
        students.push_back(student);
    }
    
    sqlite3_finalize(stmt);
    return students;
}

double StudentRepository::getAverageGradeBySubject(const std::string& subject) {
    const char* sql = "SELECT AVG(grade) FROM grades WHERE subject = ?";
    sqlite3_stmt* stmt;
    double average = 0.0;
    
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK) {
        return average;
    }
    
    sqlite3_bind_text(stmt, 1, subject.c_str(), -1, SQLITE_TRANSIENT);
    
    if (sqlite3_step(stmt) == SQLITE_ROW) {
        average = sqlite3_column_double(stmt, 0);
    }
    
    sqlite3_finalize(stmt);
    return average;
}

std::vector<Student> StudentRepository::getTopStudents(int limit) {
    const char* sql = R"(
        SELECT s.id, s.name, s.email, s.group_name, s.created_at,
               AVG(g.grade) as avg_grade
        FROM students s
        JOIN grades g ON s.id = g.student_id
        GROUP BY s.id
        HAVING COUNT(g.id) >= 3  -- хотя бы 3 оценки
        ORDER BY avg_grade DESC
        LIMIT ?
    )";
    
    sqlite3_stmt* stmt;
    std::vector<Student> students;
    
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK) {
        return students;
    }
    
    sqlite3_bind_int(stmt, 1, limit);
    
    while (sqlite3_step(stmt) == SQLITE_ROW) {
        auto student = extractStudentFromStmt(stmt);
        student.grades = getStudentGrades(student.id);
        students.push_back(student);
    }
    
    sqlite3_finalize(stmt);
    return students;
}

bool StudentRepository::batchInsertStudents(
    const std::vector<std::tuple<std::string, std::string, std::string>>& students) {
    
    beginTransaction();
    
    const char* sql = "INSERT INTO students (name, email, group_name) VALUES (?, ?, ?)";
    sqlite3_stmt* stmt;
    
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK) {
        rollbackTransaction();
        return false;
    }
    
    try {
        for (const auto& [name, email, group] : students) {
            InputValidator::validateName(name);
            InputValidator::validateEmail(email);
            InputValidator::validateGroup(group);
            
            sqlite3_reset(stmt);
            sqlite3_bind_text(stmt, 1, name.c_str(), -1, SQLITE_TRANSIENT);
            sqlite3_bind_text(stmt, 2, email.c_str(), -1, SQLITE_TRANSIENT);
            sqlite3_bind_text(stmt, 3, group.c_str(), -1, SQLITE_TRANSIENT);
            
            if (sqlite3_step(stmt) != SQLITE_DONE) {
                sqlite3_finalize(stmt);
                rollbackTransaction();
                return false;
            }
        }
        
        sqlite3_finalize(stmt);
        commitTransaction();
        return true;
        
    } catch (...) {
        rollbackTransaction();
        return false;
    }
}

// Вспомогательные методы
Student StudentRepository::extractStudentFromStmt(sqlite3_stmt* stmt) {
    Student student;
    student.id = sqlite3_column_int(stmt, 0);
    student.name = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 1));
    student.email = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 2));
    student.group_name = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 3));
    student.created_at = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 4));
    return student;
}

Grade StudentRepository::extractGradeFromStmt(sqlite3_stmt* stmt) {
    Grade grade;
    grade.id = sqlite3_column_int(stmt, 0);
    grade.student_id = sqlite3_column_int(stmt, 1);
    grade.subject = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 2));
    grade.grade = sqlite3_column_int(stmt, 3);
    grade.exam_date = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 4));
    return grade;
}

void StudentRepository::beginTransaction() {
    sqlite3_exec(db_, "BEGIN TRANSACTION", nullptr, nullptr, nullptr);
}

void StudentRepository::commitTransaction() {
    sqlite3_exec(db_, "COMMIT", nullptr, nullptr, nullptr);
}

void StudentRepository::rollbackTransaction() {
    sqlite3_exec(db_, "ROLLBACK", nullptr, nullptr, nullptr);
}