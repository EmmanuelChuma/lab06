#include "student.h"
#include <algorithm>
#include <numeric>

double Student::getAverageGrade() const {
    if (grades.empty()) return 0.0;
    
    double sum = 0.0;
    for (const auto& g : grades) {
        sum += g.grade;
    }
    return sum / grades.size();
}

int Student::getHighestGrade() const {
    if (grades.empty()) return 0;
    
    return std::max_element(grades.begin(), grades.end(),
        [](const Grade& a, const Grade& b) {
            return a.grade < b.grade;
        })->grade;
}

int Student::getLowestGrade() const {
    if (grades.empty()) return 0;
    
    return std::min_element(grades.begin(), grades.end(),
        [](const Grade& a, const Grade& b) {
            return a.grade < b.grade;
        })->grade;
}