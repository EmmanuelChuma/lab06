# Student Database Management System

## Overview

This is a C++ console application for managing student records using SQLite database. The project implements a layered architecture with separate components for database management, data validation, domain models, and data access patterns. It's designed as a laboratory exercise (Lab06) demonstrating database integration in C++ applications.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Layered Architecture Pattern

The application follows a clean separation of concerns:

1. **Domain Layer** (`student.h/cpp`)
   - Contains the Student entity/model class
   - Represents the core business object

2. **Data Access Layer** (`student_repository.h/cpp`)
   - Implements the Repository pattern for Student entities
   - Abstracts database operations (CRUD) from business logic
   - Provides a clean API for data manipulation

3. **Database Infrastructure** (`database_manager.h/cpp`)
   - Handles SQLite database connections and lifecycle
   - Manages database initialization and schema setup
   - Provides low-level database operations

4. **Input Validation** (`input_validator.h/cpp`)
   - Centralizes user input validation logic
   - Ensures data integrity before database operations

5. **Application Entry Point** (`main.cpp`)
   - Console-based user interface
   - Orchestrates user interactions with the system

### Build System

- **CMake** (version 3.10+) is used for cross-platform build configuration
- C++17 standard is required
- Compiler warnings enabled for code quality (`-Wall -Wextra -O2`)

### Design Decisions

| Decision | Rationale |
|----------|-----------|
| Repository Pattern | Decouples data access from business logic, making the code testable and maintainable |
| Separate Validation Layer | Keeps validation logic reusable and centralized |
| SQLite | Lightweight, file-based database requiring no server setup - ideal for educational projects |
| CMake | Industry-standard build system supporting multiple platforms |

## External Dependencies

### Database
- **SQLite3** - Embedded relational database
  - Header location: Platform-dependent (Nix store paths configured for Replit)
  - Used for persistent storage of student records

### Build Tools
- **CMake** 3.10+ - Build system generator
- **GCC/Clang** - C++ compiler with C++17 support

### Development Environment
- VS Code configuration files present for Windows development
- Nix-based configuration for Replit environment