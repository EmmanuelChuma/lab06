#ifndef INPUT_VALIDATOR_H
#define INPUT_VALIDATOR_H

#include <string>
#include <regex>
#include <algorithm>
#include <stdexcept>

class InputValidator {
public:
    static bool isValidEmail(const std::string& email);
    static bool isSafeInput(const std::string& input);
    static bool isValidGrade(int grade);
    static bool isValidName(const std::string& name);
    static bool isValidGroup(const std::string& group);
    
    static void validateEmail(const std::string& email);
    static void validateName(const std::string& name);
    static void validateGroup(const std::string& group);
    static void validateGrade(int grade);
    
private:
    static const std::regex email_regex_;
    static const std::string dangerous_patterns_[];
};

#endif // INPUT_VALIDATOR_H