#ifndef STUDENT_H
#define STUDENT_H

#include <string>
#include <vector>
#include <ctime>

struct Grade {
    int id;
    int student_id;
    std::string subject;
    int grade;
    std::string exam_date;
};

struct Student {
    int id;
    std::string name;
    std::string email;
    std::string group_name;
    std::string created_at;
    std::vector<Grade> grades;
    
    double getAverageGrade() const;
    int getHighestGrade() const;
    int getLowestGrade() const;
};

#endif // STUDENT_H