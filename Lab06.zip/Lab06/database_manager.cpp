#include "database_manager.h"
#include <iostream>

DatabaseManager::DatabaseManager(const std::string& db_path) 
    : db_(nullptr), db_path_(db_path) {
    
    int rc = sqlite3_open(db_path.c_str(), &db_);
    if (rc != SQLITE_OK) {
        std::string error = "Cannot open database: " + 
                           std::string(sqlite3_errmsg(db_));
        sqlite3_close(db_);
        throw std::runtime_error(error);
    }
    
    enableForeignKeys();
}

DatabaseManager::~DatabaseManager() {
    if (db_) {
        sqlite3_close(db_);
    }
}

void DatabaseManager::enableForeignKeys() {
    char* errMsg = nullptr;
    int rc = sqlite3_exec(db_, "PRAGMA foreign_keys = ON;", 
                         nullptr, nullptr, &errMsg);
    if (rc != SQLITE_OK) {
        std::cerr << "Failed to enable foreign keys: " << errMsg << std::endl;
        sqlite3_free(errMsg);
    }
}

void DatabaseManager::initializeDatabase() {
    createStudentsTable();
    createGradesTable();
    createIndexes();
    
    // Оптимизация
    char* errMsg = nullptr;
    sqlite3_exec(db_, "PRAGMA journal_mode = WAL;", nullptr, nullptr, &errMsg);
    sqlite3_exec(db_, "PRAGMA synchronous = NORMAL;", nullptr, nullptr, &errMsg);
    sqlite3_exec(db_, "PRAGMA cache_size = 10000;", nullptr, nullptr, &errMsg);
}

void DatabaseManager::createStudentsTable() {
    const char* sql = R"(
        CREATE TABLE IF NOT EXISTS students (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            group_name TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    )";
    
    char* errMsg = nullptr;
    int rc = sqlite3_exec(db_, sql, nullptr, nullptr, &errMsg);
    if (rc != SQLITE_OK) {
        std::string error = "Failed to create students table: " + 
                           std::string(errMsg);
        sqlite3_free(errMsg);
        throw std::runtime_error(error);
    }
}

void DatabaseManager::createGradesTable() {
    const char* sql = R"(
        CREATE TABLE IF NOT EXISTS grades (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER NOT NULL,
            subject TEXT NOT NULL,
            grade INTEGER NOT NULL CHECK (grade >= 0 AND grade <= 100),
            exam_date DATE DEFAULT CURRENT_DATE,
            FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
        )
    )";
    
    char* errMsg = nullptr;
    int rc = sqlite3_exec(db_, sql, nullptr, nullptr, &errMsg);
    if (rc != SQLITE_OK) {
        std::string error = "Failed to create grades table: " + 
                           std::string(errMsg);
        sqlite3_free(errMsg);
        throw std::runtime_error(error);
    }
}

void DatabaseManager::createIndexes() {
    const char* indexes[] = {
        "CREATE INDEX IF NOT EXISTS idx_students_email ON students(email);",
        "CREATE INDEX IF NOT EXISTS idx_students_group ON students(group_name);",
        "CREATE INDEX IF NOT EXISTS idx_grades_student_id ON grades(student_id);",
        "CREATE INDEX IF NOT EXISTS idx_grades_subject ON grades(subject);",
        "CREATE INDEX IF NOT EXISTS idx_grades_grade ON grades(grade);"
    };
    
    char* errMsg = nullptr;
    for (const auto& sql : indexes) {
        int rc = sqlite3_exec(db_, sql, nullptr, nullptr, &errMsg);
        if (rc != SQLITE_OK) {
            std::cerr << "Failed to create index: " << errMsg << std::endl;
            sqlite3_free(errMsg);
            errMsg = nullptr;
        }
    }
}