#include "input_validator.h"
#include <iostream>

const std::regex InputValidator::email_regex_(
    R"(^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$)"
);

const std::string InputValidator::dangerous_patterns_[] = {
    "--", ";", "/*", "*/", "' OR", "\" OR", "DROP TABLE", 
    "DELETE FROM", "UPDATE ", "INSERT INTO", "SELECT *"
};

bool InputValidator::isValidEmail(const std::string& email) {
    return std::regex_match(email, email_regex_) && 
           email.length() <= 100;
}

bool InputValidator::isSafeInput(const std::string& input) {
    std::string upper_input = input;
    std::transform(upper_input.begin(), upper_input.end(), 
                  upper_input.begin(), ::toupper);
    
    for (const auto& pattern : dangerous_patterns_) {
        if (upper_input.find(pattern) != std::string::npos) {
            return false;
        }
    }
    return input.length() <= 255;
}

bool InputValidator::isValidGrade(int grade) {
    return grade >= 0 && grade <= 100;
}

bool InputValidator::isValidName(const std::string& name) {
    return !name.empty() && name.length() <= 100 && isSafeInput(name);
}

bool InputValidator::isValidGroup(const std::string& group) {
    return !group.empty() && group.length() <= 50 && isSafeInput(group);
}

void InputValidator::validateEmail(const std::string& email) {
    if (!isValidEmail(email)) {
        throw std::invalid_argument("Invalid email format or length > 100");
    }
}

void InputValidator::validateName(const std::string& name) {
    if (!isValidName(name)) {
        throw std::invalid_argument("Invalid name (empty, too long, or unsafe)");
    }
}

void InputValidator::validateGroup(const std::string& group) {
    if (!isValidGroup(group)) {
        throw std::invalid_argument("Invalid group (empty, too long, or unsafe)");
    }
}

void InputValidator::validateGrade(int grade) {
    if (!isValidGrade(grade)) {
        throw std::invalid_argument("Grade must be between 0 and 100");
    }
}