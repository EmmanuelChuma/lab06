#ifndef STUDENT_REPOSITORY_H
#define STUDENT_REPOSITORY_H

#include "student.h"
#include "input_validator.h"
#include <sqlite3.h>
#include <vector>
#include <memory>
#include <optional>

class StudentRepository {
public:
    explicit StudentRepository(sqlite3* db);
    
    // Основные CRUD операции
    bool addStudent(const std::string& name, const std::string& email, 
                   const std::string& group);
    std::optional<Student> getStudent(int id);
    bool updateStudent(int id, const std::string& newName, 
                      const std::string& newEmail, const std::string& newGroup);
    bool deleteStudent(int id);
    std::vector<Student> getAllStudents();
    
    // Работа с оценками
    bool addGrade(int student_id, const std::string& subject, int grade);
    std::vector<Grade> getStudentGrades(int student_id);
    
    // Транзакции
    bool addStudentWithGrades(const std::string& name, const std::string& email,
                            const std::string& group, 
                            const std::vector<std::pair<std::string, int>>& grades);
    
    // Статистика и сложные запросы
    std::vector<Student> getStudentsByGroup(const std::string& group_name);
    double getAverageGradeBySubject(const std::string& subject);
    std::vector<Student> getTopStudents(int limit);
    std::vector<Student> getStudentsWithAverageAbove(double threshold);
    
    // Пакетная вставка
    bool batchInsertStudents(const std::vector<std::tuple<std::string, 
                           std::string, std::string>>& students);
    
private:
    sqlite3* db_;
    
    Student extractStudentFromStmt(sqlite3_stmt* stmt);
    Grade extractGradeFromStmt(sqlite3_stmt* stmt);
    
    void beginTransaction();
    void commitTransaction();
    void rollbackTransaction();
};

#endif // STUDENT_REPOSITORY_H